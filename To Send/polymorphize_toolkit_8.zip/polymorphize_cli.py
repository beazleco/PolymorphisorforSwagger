#!/usr/bin/env python3
"""
polymorphize_cli.py
===================

Command-line front-end for polymorphize_core. Fully parameterised.

Examples
--------
Basic (auto-detect the polymorphism families and de-duplication):

    python polymorphize_cli.py \
        --swagger cheque.yaml --mapping cheque.xlsx \
        --out cheque_polymorphic.yaml --report report.md \
        --auto-poly --auto-dedupe --discriminator

Explicit groups / de-dupe:

    python polymorphize_cli.py --swagger cheque.yaml --mapping cheque.xlsx \
        --out out.yaml \
        --poly "ChequeProcessingResultBase = ChequeSubmissionResponse:submission, ChequeEnquiryResponse:enquiry" \
        --dedupe "ChequeEnquiryRequest.chequeProcessingOperatingSession = chequeProcessingOperatingSession"
"""
import argparse
import sys

import polymorphize_core as core


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Eliminate non-SOR attributes from an OpenAPI file using polymorphism.")
    ap.add_argument("--swagger", required=True, help="input OpenAPI/Swagger YAML")
    ap.add_argument("--mapping", required=True, help="SOR mapping spreadsheet (.xlsx) — exactly one")
    ap.add_argument("--sor-swagger", action="append", default=[], metavar="YAML",
                    help="SOR API YAML used to validate mapped fields (repeatable, or ';'-separate)")
    ap.add_argument("--require-sor-field", action="store_true",
                    help="also eliminate a mapped attribute if its SOR field is absent from the SOR YAML(s)")
    ap.add_argument("--out", required=True, help="output YAML path")
    ap.add_argument("--report", default=None, help="optional Markdown report path")
    ap.add_argument("--html-report", default=None,
                    help="optional colour-coded HTML diff report path")

    ap.add_argument("--keep-absent", action="store_true",
                    help="keep attributes merely absent from the sheet (drop only explicit non-SOR)")
    ap.add_argument("--discriminator", action="store_true",
                    help="add discriminator + mapping to generated base schemas")
    ap.add_argument("--disc-prop", default="resultContext",
                    help="discriminator property name (default: resultContext)")

    ap.add_argument("--poly", action="append", default=[], metavar="SPEC",
                    help="polymorphism group 'Base = SchemaA:valA, SchemaB:valB' (repeatable)")
    ap.add_argument("--dedupe", action="append", default=[], metavar="SPEC",
                    help="inline de-dupe 'Owner.prop = Target' (repeatable)")
    ap.add_argument("--auto-poly", action="store_true",
                    help="auto-detect request/response families to factor (if no --poly given)")
    ap.add_argument("--auto-dedupe", action="store_true",
                    help="auto-replace inline objects identical to a named schema")
    ap.add_argument("--protected", default="ErrorResponse",
                    help="comma-separated schema names never pruned (default: ErrorResponse)")

    # spreadsheet column configuration (1-based column numbers)
    ap.add_argument("--level-first-col", type=int, default=core.DEFAULT_SHEET_CFG["level_first_col"])
    ap.add_argument("--level-last-col", type=int, default=core.DEFAULT_SHEET_CFG["level_last_col"])
    ap.add_argument("--dtype-col", type=int, default=core.DEFAULT_SHEET_CFG["dtype_col"])
    ap.add_argument("--sor-col", type=int, default=core.DEFAULT_SHEET_CFG["sor_col"])
    ap.add_argument("--not-used-text", default=core.DEFAULT_SHEET_CFG["not_used_text"])

    args = ap.parse_args(argv)

    sor_swaggers = []
    for s in args.sor_swagger:
        sor_swaggers.extend(p.strip() for p in str(s).split(";") if p.strip())

    groups = [core.parse_group_spec(s) for s in args.poly]
    dedupe = [core.parse_dedupe_spec(s) for s in args.dedupe]
    sheet_cfg = {
        "level_first_col": args.level_first_col,
        "level_last_col": args.level_last_col,
        "dtype_col": args.dtype_col,
        "sor_col": args.sor_col,
        "not_used_text": args.not_used_text,
    }
    protected = tuple(s.strip() for s in args.protected.split(",") if s.strip())

    result = core.run(
        args.swagger, args.mapping, args.out, args.report, html_report=args.html_report,
        sor_swaggers=sor_swaggers, require_sor_field=args.require_sor_field,
        keep_absent=args.keep_absent, add_discriminator=args.discriminator,
        discriminator_prop=args.disc_prop, poly_groups=groups, dedupe_pairs=dedupe,
        auto_poly=args.auto_poly, auto_dedupe=args.auto_dedupe,
        protected=protected, sheet_cfg=sheet_cfg, log=lambda m: print(m),
    )

    print(f"\nEliminated {len(result['dropped'])} non-SOR attribute(s):")
    for pathname, reason in result["dropped"]:
        print(f"  - {pathname}  ({reason})")
    for line in result["poly_log"]:
        print(f"  poly: {line}")
    for line in result["dedupe_log"]:
        print(f"  dedupe: {line}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
