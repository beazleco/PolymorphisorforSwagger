#!/usr/bin/env python3
"""
polymorphize_batch.py
=====================

Run the SOR polymorphism refactor over MANY swaggers in one go, driven by a
manifest (CSV or Excel) that lists one job per row.

Each row needs at least ``swagger`` and ``mapping``; everything else is
optional and falls back to a sensible default. Relative paths in the manifest
are resolved against the manifest's own folder (override with --base-dir).

Manifest columns (header row, case-insensitive; unknown columns ignored)
------------------------------------------------------------------------
    name             friendly label for the report (default: swagger filename)
    swagger          input OpenAPI file                              [required]
    mapping          SOR mapping spreadsheet (.xlsx)                 [required]
    out              output file (default: <swagger>_polymorphic.yaml)
    report           optional Markdown report path
    html_report      optional HTML diff path (default: <out>_changes.html)
    discriminator    add discriminator to base schemas   (default: true)
    auto_poly        auto-detect polymorphism families   (default: true)
    auto_dedupe      auto de-duplicate inline objects    (default: true)
    keep_absent      keep attributes absent from sheet   (default: false)
    disc_prop        discriminator property name         (default: resultContext)
    protected        schemas never pruned                (default: ErrorResponse)
    poly             explicit group(s), ';'-separated (overrides auto_poly)
    dedupe           explicit de-dupe(s), ';'-separated
    level_first_col / level_last_col / dtype_col / sor_col / not_used_text
                     spreadsheet layout, if it differs from the default

Outputs
-------
    <each job's out + html>                    the transformed swaggers
    batch_summary.csv                          one row per job, with counts/status
    batch_index.html                           linked roll-up you can open in a browser

Usage
-----
    python polymorphize_batch.py --manifest jobs.csv --jobs 4
"""
import argparse
import concurrent.futures as cf
import csv
import html as _html
import os
import sys

import openpyxl

import polymorphize_core as core

BOOL_TRUE = {"1", "true", "yes", "y", "on", "t"}


# --------------------------------------------------------------------------- #
# Manifest loading
# --------------------------------------------------------------------------- #
def load_manifest(path):
    rows = []
    if path.lower().endswith((".xlsx", ".xlsm")):
        wb = openpyxl.load_workbook(path, data_only=True)
        ws = wb.active
        it = ws.iter_rows(values_only=True)
        headers = [str(h).strip().lower() if h is not None else "" for h in next(it)]
        for r in it:
            if not any(c not in (None, "") for c in r):
                continue
            rows.append({h: v for h, v in zip(headers, r) if h})
    else:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            for row in csv.DictReader(fh):
                rows.append({(k or "").strip().lower(): v for k, v in row.items()})
    return rows


def _split_multi(text):
    if not text:
        return []
    parts = []
    for chunk in str(text).replace("\n", ";").split(";"):
        chunk = chunk.strip()
        if chunk:
            parts.append(chunk)
    return parts


def build_job(row, base_dir, idx):
    def g(*names, default=None):
        for n in names:
            if n in row and row[n] is not None and str(row[n]).strip() != "":
                return str(row[n]).strip()
        return default

    def gb(*names, default=False):
        v = g(*names)
        return default if v is None else (v.strip().lower() in BOOL_TRUE)

    def gi(name, default):
        v = g(name)
        try:
            return int(float(v)) if v is not None else default
        except ValueError:
            return default

    def resolve(p):
        if not p:
            return None
        return p if os.path.isabs(p) else os.path.normpath(os.path.join(base_dir, p))

    swagger = resolve(g("swagger", "input"))
    mapping = resolve(g("mapping", "spreadsheet"))          # exactly one spreadsheet
    sor_swaggers = [resolve(p) for p in _split_multi(g("sor_swagger", "sor_yaml", "sor"))]
    out = resolve(g("out", "output"))
    if not out and swagger:
        stem = os.path.splitext(swagger)[0]
        out = stem + "_polymorphic.yaml"
    report = resolve(g("report", "md_report"))
    html = resolve(g("html_report", "html"))
    if not html and out:
        html = os.path.splitext(out)[0] + "_changes.html"

    sheet_cfg = {
        "level_first_col": gi("level_first_col", core.DEFAULT_SHEET_CFG["level_first_col"]),
        "level_last_col": gi("level_last_col", core.DEFAULT_SHEET_CFG["level_last_col"]),
        "dtype_col": gi("dtype_col", core.DEFAULT_SHEET_CFG["dtype_col"]),
        "sor_col": gi("sor_col", core.DEFAULT_SHEET_CFG["sor_col"]),
        "not_used_text": g("not_used_text", default=core.DEFAULT_SHEET_CFG["not_used_text"]),
    }
    poly = [core.parse_group_spec(s) for s in _split_multi(g("poly", "poly_groups"))]
    dedupe = [core.parse_dedupe_spec(s) for s in _split_multi(g("dedupe"))]

    return {
        "name": g("name") or (os.path.basename(swagger) if swagger else f"job{idx + 1}"),
        "swagger": swagger, "mapping": mapping, "out": out, "report": report, "html": html,
        "sor_swaggers": sor_swaggers, "require_sor_field": gb("require_sor_field"),
        "keep_absent": gb("keep_absent"),
        "add_discriminator": gb("discriminator", default=True),
        "disc_prop": g("disc_prop", default="resultContext"),
        "poly": poly, "dedupe": dedupe,
        # detect per-file automatically; a template 'poly'/'dedupe' entry overrides
        "auto_poly": gb("auto_poly", default=not poly),
        "auto_dedupe": gb("auto_dedupe", default=not dedupe),
        "protected": tuple(s.strip() for s in g("protected", default="ErrorResponse").split(",") if s.strip()),
        "sheet_cfg": sheet_cfg,
    }


# --------------------------------------------------------------------------- #
# Worker (module-level so it is picklable for ProcessPoolExecutor)
# --------------------------------------------------------------------------- #
def run_job(job):
    name = job["name"]
    try:
        if not job["swagger"] or not os.path.isfile(job["swagger"]):
            raise FileNotFoundError(f"swagger not found: {job['swagger']}")
        if not job["mapping"] or not os.path.isfile(job["mapping"]):
            raise FileNotFoundError(f"mapping not found: {job['mapping']}")
        for y in job["sor_swaggers"]:
            if not y or not os.path.isfile(y):
                raise FileNotFoundError(f"SOR YAML not found: {y}")
        for p in (job["out"], job["report"], job["html"]):
            if p:
                os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
        res = core.run(
            job["swagger"], job["mapping"], job["out"], job["report"],
            html_report=job["html"], sor_swaggers=job["sor_swaggers"],
            require_sor_field=job["require_sor_field"], keep_absent=job["keep_absent"],
            add_discriminator=job["add_discriminator"], discriminator_prop=job["disc_prop"],
            poly_groups=job["poly"], dedupe_pairs=job["dedupe"],
            auto_poly=job["auto_poly"], auto_dedupe=job["auto_dedupe"],
            protected=job["protected"], sheet_cfg=job["sheet_cfg"], log=lambda m: None,
        )
        return {"name": name, "status": "ok", "out": job["out"], "html": job["html"],
                "eliminated": len(res["dropped"]), "poly": len(res["poly_log"]),
                "dedup": len(res["dedupe_log"]), "error": ""}
    except Exception as e:  # noqa: BLE001 - report, never abort the batch
        return {"name": name, "status": "ERROR", "out": job["out"], "html": None,
                "eliminated": 0, "poly": 0, "dedup": 0, "error": f"{type(e).__name__}: {e}"}


# --------------------------------------------------------------------------- #
# Consolidated reports
# --------------------------------------------------------------------------- #
def write_summary_csv(path, results):
    cols = ["name", "status", "eliminated", "poly", "dedup", "out", "html", "error"]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in results:
            w.writerow({c: r.get(c, "") for c in cols})


def write_index_html(path, results):
    base = os.path.dirname(os.path.abspath(path))

    def rel(p):
        try:
            return os.path.relpath(p, base) if p else ""
        except ValueError:
            return p or ""

    ok = [r for r in results if r["status"] == "ok"]
    failed = [r for r in results if r["status"] != "ok"]
    tot_elim = sum(r["eliminated"] for r in ok)
    tot_poly = sum(r["poly"] for r in ok)

    trs = []
    for r in results:
        status_cls = "ok" if r["status"] == "ok" else "bad"
        out_link = f'<a href="{_html.escape(rel(r["out"]))}">yaml</a>' if r.get("out") and r["status"] == "ok" else ""
        html_link = f'<a href="{_html.escape(rel(r["html"]))}">diff</a>' if r.get("html") else ""
        trs.append(
            f'<tr><td>{_html.escape(str(r["name"]))}</td>'
            f'<td class="{status_cls}">{_html.escape(r["status"])}</td>'
            f'<td class="num">{r["eliminated"]}</td><td class="num">{r["poly"]}</td>'
            f'<td class="num">{r["dedup"]}</td><td>{out_link}</td><td>{html_link}</td>'
            f'<td class="err">{_html.escape(r["error"])}</td></tr>')

    core._write(path, f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>SOR Polymorphizer - batch index</title><style>
 body{{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f8;color:#1f2a33}}
 header{{background:#21295C;color:#fff;padding:20px 28px}} header h1{{margin:0;font-size:20px}}
 .wrap{{padding:22px 28px;max-width:1150px;margin:0 auto}}
 .cards{{display:flex;gap:14px;margin-bottom:20px;flex-wrap:wrap}}
 .card{{background:#fff;border-radius:10px;padding:16px 20px;box-shadow:0 1px 4px rgba(0,0,0,.1);min-width:130px}}
 .card .n{{font-size:30px;font-weight:700;color:#065A82}} .card .l{{font-size:13px;color:#5A6B78}}
 table{{border-collapse:collapse;width:100%;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
 td,th{{padding:8px 12px;border-bottom:1px solid #eef2f5;text-align:left;font-size:13px}}
 th{{background:#eef3f7}} .num{{text-align:right;font-variant-numeric:tabular-nums}}
 .ok{{color:#1E7A34;font-weight:600}} .bad{{color:#B3261E;font-weight:700}} .err{{color:#B3261E;font-size:12px}}
 a{{color:#065A82}}
</style></head><body>
<header><h1>SOR Polymorphizer — batch results</h1></header>
<div class="wrap">
 <div class="cards">
  <div class="card"><div class="n">{len(results)}</div><div class="l">swaggers processed</div></div>
  <div class="card"><div class="n">{len(ok)}</div><div class="l">succeeded</div></div>
  <div class="card"><div class="n">{len(failed)}</div><div class="l">failed</div></div>
  <div class="card"><div class="n">{tot_elim}</div><div class="l">attributes eliminated</div></div>
  <div class="card"><div class="n">{tot_poly}</div><div class="l">polymorphism actions</div></div>
 </div>
 <table><tr><th>Job</th><th>Status</th><th>Elim.</th><th>Poly</th><th>De-dup</th>
  <th>Output</th><th>Report</th><th>Error</th></tr>
 {''.join(trs)}
 </table>
</div></body></html>""")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main(argv=None):
    ap = argparse.ArgumentParser(description="Batch-run the SOR polymorphism refactor from a manifest.")
    ap.add_argument("--manifest", required=True, help="CSV or Excel manifest, one job per row")
    ap.add_argument("--base-dir", default=None, help="resolve relative paths against this folder (default: manifest folder)")
    ap.add_argument("--jobs", type=int, default=1, help="parallel workers (default 1)")
    ap.add_argument("--summary-csv", default=None, help="summary CSV path (default: batch_summary.csv next to manifest)")
    ap.add_argument("--index", default=None, help="HTML index path (default: batch_index.html next to manifest)")
    args = ap.parse_args(argv)

    if not os.path.isfile(args.manifest):
        print(f"Manifest not found: {args.manifest}", file=sys.stderr)
        return 2
    base_dir = args.base_dir or os.path.dirname(os.path.abspath(args.manifest))
    mdir = os.path.dirname(os.path.abspath(args.manifest))
    summary_csv = args.summary_csv or os.path.join(mdir, "batch_summary.csv")
    index_html = args.index or os.path.join(mdir, "batch_index.html")

    rows = load_manifest(args.manifest)
    jobs = [build_job(r, base_dir, i) for i, r in enumerate(rows)]
    if not jobs:
        print("Manifest has no job rows.", file=sys.stderr)
        return 2

    print(f"Processing {len(jobs)} swagger(s) with {max(1, args.jobs)} worker(s)…\n")
    results = []
    if args.jobs and args.jobs > 1:
        with cf.ProcessPoolExecutor(max_workers=args.jobs) as ex:
            for res in ex.map(run_job, jobs):
                results.append(res)
                _print_line(res)
    else:
        for job in jobs:
            res = run_job(job)
            results.append(res)
            _print_line(res)

    # keep manifest order
    write_summary_csv(summary_csv, results)
    write_index_html(index_html, results)

    ok = sum(1 for r in results if r["status"] == "ok")
    failed = len(results) - ok
    tot = sum(r["eliminated"] for r in results if r["status"] == "ok")
    print(f"\nDone. {ok} ok, {failed} failed, {tot} attributes eliminated in total.")
    print(f"Summary : {summary_csv}")
    print(f"Index   : {index_html}")
    return 1 if failed else 0


def _print_line(res):
    tag = "OK " if res["status"] == "ok" else "ERR"
    extra = (f"elim={res['eliminated']} poly={res['poly']} dedup={res['dedup']}"
             if res["status"] == "ok" else res["error"])
    print(f"  [{tag}] {res['name']:<40} {extra}")


if __name__ == "__main__":
    sys.exit(main())
