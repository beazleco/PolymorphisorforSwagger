# SOR Polymorphizer

Tools that inspect an OpenAPI/Swagger file and produce a new one in which
attributes **with no System-of-Record (SOR) connection are eliminated**, using
OpenAPI polymorphism (`allOf` sub-typing, optionally with a `discriminator`) so
that schemas shared across operations no longer carry unused / empty attributes.

The SOR connection for each attribute is read from the data-model **mapping
spreadsheet** (one file — the `SOR Field` column). Optionally, one or more of
the System-of-Record's own **SOR API YAML files** can be supplied to validate
that the mapped fields actually exist in the SOR. A leaf attribute is kept when it maps to
a concrete SOR field, and eliminated when the sheet shows `Not Used In SOR`,
blank, or has no row for it. Classes (`object` / `array`) are structural and are
never removed for lacking an SOR field — only their leaf attributes are.

## Files

| File | Purpose |
|------|---------|
| `polymorphize_core.py` | The engine. Fully parameterised, no hard-coded names. |
| `polymorphize_cli.py`  | Command-line front-end. |
| `polymorphize_gui.py`  | Windows desktop app (Tkinter) with browse buttons + log. |
| `build_windows_exe.bat`| One-click PyInstaller build → `dist\PolymorphizeSwagger.exe`. |
| `polymorphize_batch.py`| Batch runner — process many swaggers from a manifest. |
| `run_batch.bat`        | Windows launcher for the batch runner. |
| `manifest_template.csv` / `.xlsx` | Starter manifest to copy and fill in. |

## Windows application (recommended for non-technical users)

1. Install Python 3.9+ from python.org (tick “Add python.exe to PATH”).
2. Double-click **`build_windows_exe.bat`**. It installs the dependencies and
   produces **`dist\PolymorphizeSwagger.exe`** — a single self-contained file.
3. Share/run that `.exe`; end-users need **no** Python install.

The three actions are numbered on screen — **STEP 1 choose files → STEP 2
Analyze → STEP 3 Run (approve)** — and the Run button stays disabled until you
have analyzed:

1. **STEP 1** — choose the input Swagger and **one** SOR mapping spreadsheet.
   Optionally attach **one or more SOR API YAML files** (the System-of-Record's
   own specs) with the **Add…** button or by dropping them onto the list — these
   are used to *validate* that every mapped attribute's SOR field really exists
   in the SOR (and, if you tick the option, to eliminate mapped attributes whose
   SOR field is absent from the SOR). (drag-and-drop or Browse.)
2. **STEP 2 — Analyze.** Because the objects in a swagger differ from file to
   file, the polymorphism groups, inline de-duplications *and the discriminator
   name* are detected *from the files you just entered* and filled into the
   boxes for review (edit to override). The log lists exactly what would be
   eliminated.
3. **STEP 3 — Run transform**, then **approve** the summarised changes. Nothing
   is written until you approve. Changing any input invalidates the analysis and
   you must Analyze again — so an approval always reflects the current files.

### Seeing what changed
Every change the tool makes is highlighted three ways:

* **In the app log** — a colour-coded summary (red = attribute removed, green =
  added / restructured), plus counts.
* **A one-click HTML change report** — click **Open change report** for a
  self-contained page with summary cards, an eliminated-attributes table, and a
  full red/green diff of the original vs the new file.
* **Inside the output swagger itself** — a banner comment at the top, an
  `info.x-sor-polymorphizer` record listing every change, and `>>> CHANGE`
  comments at each edited schema.

### Drag-and-drop
Drag-and-drop uses the small `tkinterdnd2` package. `build_windows_exe.bat`
installs and bundles it automatically. If it is ever missing, the app still runs
and you simply use the Browse buttons.

> The `.exe` must be built on Windows — PyInstaller is not a cross-compiler.
> You can also just run `python polymorphize_gui.py` on any OS with Python.

## Command line

```bash
pip install ruamel.yaml openpyxl

python polymorphize_cli.py \
    --swagger apicoechequeprocessingswaggerv1.0.0.yaml \
    --mapping "datamodelChequeProcessingV1  Example.xlsx" \
    --out cheque_polymorphic.yaml --report report.md \
    --poly "ChequeProcessingResultBase = ChequeSubmissionResponse:submission, ChequeEnquiryResponse:enquiry" \
    --dedupe "ChequeEnquiryRequest.chequeProcessingOperatingSession = chequeProcessingOperatingSession" \
    --discriminator
```

Or let it find the families itself:

```bash
python polymorphize_cli.py --swagger cheque.yaml --mapping cheque.xlsx \
    --out out.yaml --auto-poly --auto-dedupe --discriminator
```

### Parameters

| Parameter | Meaning |
|-----------|---------|
| `--swagger` / `--out` / `--report` | input, output, report paths |
| `--mapping` | SOR mapping spreadsheet — exactly one |
| `--sor-swagger` | SOR API YAML to validate mapped fields — **repeatable**, or `;`-separate |
| `--require-sor-field` | also eliminate a mapped attribute if its SOR field is absent from the SOR YAML(s) |
| `--html-report` | colour-coded HTML diff of the changes |
| `--poly "Base = A:v1, B:v2"` | factor schemas A,B into a shared base (repeatable) |
| `--dedupe "Owner.prop = Target"` | replace an inline object with a `$ref` (repeatable) |
| `--auto-poly` / `--auto-dedupe` | auto-detect families / inline duplicates |
| `--discriminator` / `--disc-prop` | add a discriminator + name it |
| `--keep-absent` | keep attributes merely absent from the sheet |
| `--protected` | schema names never pruned (default `ErrorResponse`) |
| `--level-first-col`/`--level-last-col`/`--dtype-col`/`--sor-col`/`--not-used-text` | spreadsheet layout, if it differs |

## Batch — many swaggers at once

For a large number of files, drive the run from a **manifest** (one job per row).
Start from `manifest_template.csv` (or `.xlsx`): each row lists at least a
`swagger` and its `mapping`; everything else has a sensible default (auto-detect
polymorphism, auto de-dup, discriminator on). Relative paths are resolved
against the manifest's own folder. Use one `mapping` spreadsheet per row; the
optional `sor_swagger` cell may list **several SOR API YAML files separated by
`;`** (used to validate the mapped fields), and `require_sor_field` (true/false)
turns on strict elimination for that row.

```bash
python polymorphize_batch.py --manifest jobs.csv --jobs 4
```

On Windows, **drag your manifest onto `run_batch.bat`** (or put `manifest.csv`
next to it and double-click). It writes:

* each transformed swagger + its HTML change report,
* `batch_summary.csv` — one row per job (status, counts, paths, any error),
* `batch_index.html` — a linked roll-up: totals, per-job status (green ok /
  red failed), and links straight to each output and diff.

`--jobs N` runs N files in parallel. A file that fails is reported and skipped —
it never aborts the rest of the batch.

**Same rule as the GUI, applied automatically:** the groups and de-duplications
are detected *per file* at run time (the objects can differ between files), so
you normally leave the `poly` and `dedupe` columns **blank**. Fill a `poly` or
`dedupe` cell only when you want to *override* the auto-detection for that one
file — an explicit entry takes precedence over the automatic proposal.

## Notes

- **Discriminator trade-off:** with `--discriminator` a required selector
  property is added to each generated base. Omit it for pure `allOf`
  inheritance — the elimination of non-SOR attributes is identical either way.
- **Pre-existing spec issue:** the source swagger declares path
  `/ChequeProcessing/{chequeprocessingid}/Retrieve` without defining the
  `chequeprocessingid` path parameter. That validation warning exists on the
  input already and is not introduced by this tool.
