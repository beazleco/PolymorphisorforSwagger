#!/usr/bin/env python3
"""
polymorphize_gui.py  —  SOR Polymorphizer (Windows GUI)
=======================================================

Order of actions is numbered on screen:

    STEP 1  Choose files   (input swagger + ONE SOR mapping spreadsheet;
                            optionally one OR MORE SOR API YAML files)
    STEP 2  Analyze        (detects eliminations / groups / de-dup / discriminator,
                            and — if SOR YAMLs are supplied — validates that every
                            mapped attribute's SOR field really exists in the SOR)
    STEP 3  Run transform  (approve the summarised changes; nothing is written
                            until you approve)

Exactly one mapping spreadsheet is used. Several SOR API YAML files may be
attached — they define the fields the System-of-Record actually exposes and are
used to VALIDATE the mapping (and, if you tick the option, to eliminate mapped
attributes whose SOR field is absent from the SOR).

Drag-and-drop needs the optional 'tkinterdnd2' package (bundled by the build
script); it falls back to Browse-only if absent.
"""
import os
import queue
import re
import threading
import traceback
import webbrowser

import tkinter as tk
from tkinter import filedialog, messagebox, ttk, scrolledtext

import polymorphize_core as core

try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    _HAS_DND = True
except Exception:
    TkinterDnD = None
    DND_FILES = None
    _HAS_DND = False

__version__ = "4.1 (SOR YAML validation · numbered steps)"
APP_TITLE = f"SOR Polymorphizer  v{__version__}"


def _parse_drops(data):
    return [m[1:-1] if m.startswith("{") and m.endswith("}") else m
            for m in re.findall(r"\{[^}]*\}|\S+", data.strip())]


def _first_drop(data):
    parts = _parse_drops(data)
    return parts[0] if parts else ""


class App:
    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry("920x920")
        root.minsize(820, 740)
        self.q = queue.Queue()
        self.sor_swaggers = []       # optional list of SOR API YAML paths
        self.last_out = None
        self.last_html = None
        self.analysis = None
        self.analyzed_sig = None
        self._make_styles()
        self._build()
        self.root.after(100, self._drain_log)

    def _make_styles(self):
        st = ttk.Style()
        try:
            st.theme_use("vista")
        except tk.TclError:
            pass
        st.configure("Step.TButton", font=("Segoe UI", 11, "bold"), padding=(10, 8))
        st.configure("Arrow.TLabel", font=("Segoe UI", 16, "bold"), foreground="#065A82")
        st.configure("StepHdr.TLabelframe.Label", font=("Segoe UI", 10, "bold"), foreground="#21295C")

    # ---- single-file row --------------------------------------------------- #
    def _file_row(self, parent, label, r, save=False, kinds=None, invalidates=False):
        ttk.Label(parent, text=label).grid(row=r, column=0, sticky="w", padx=6, pady=5)
        var = tk.StringVar()
        ent = ttk.Entry(parent, textvariable=var, width=62)
        ent.grid(row=r, column=1, sticky="we", padx=6, pady=5)
        ttk.Button(parent, text="Browse…",
                   command=lambda: self._browse(var, save, kinds)).grid(row=r, column=2, padx=6, pady=5)
        self._enable_single_drop(ent, var)
        if invalidates:
            var.trace_add("write", lambda *a: self._invalidate())
        return var

    def _enable_single_drop(self, widget, var):
        if not _HAS_DND or not hasattr(widget, "drop_target_register"):
            return
        try:
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", lambda e, v=var: v.set(_first_drop(e.data)))
        except tk.TclError:
            pass

    def _browse(self, var, save, kinds):
        kinds = kinds or [("All files", "*.*")]
        if save:
            p = filedialog.asksaveasfilename(filetypes=kinds,
                                             defaultextension=kinds[0][1].split()[0].replace("*", ""))
        else:
            p = filedialog.askopenfilename(filetypes=kinds)
        if p:
            var.set(p)

    # ---- build ------------------------------------------------------------- #
    def _build(self):
        pad = dict(padx=6, pady=4)
        top = "Order:   1  choose files    ➜    2  Analyze    ➜    review boxes    ➜    3  Run  (approve)"
        ttk.Label(self.root, text=top, foreground="#21295C",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=16, pady=(10, 2))
        dhint = ("Drag files onto the boxes, or use Browse / Add."
                 if _HAS_DND else "Install 'tkinterdnd2' for drag-and-drop; use Browse / Add for now.")
        ttk.Label(self.root, text=dhint, foreground="#5A6B78").pack(anchor="w", padx=16)

        yaml_kinds = [("YAML", "*.yaml *.yml"), ("All files", "*.*")]
        xlsx_kinds = [("Excel", "*.xlsx *.xlsm"), ("All files", "*.*")]
        md_kinds = [("Markdown", "*.md"), ("All files", "*.*")]
        html_kinds = [("HTML", "*.html"), ("All files", "*.*")]

        files = ttk.LabelFrame(self.root, text="STEP 1 · Choose files", style="StepHdr.TLabelframe")
        files.pack(fill="x", padx=10, pady=(4, 6))
        files.columnconfigure(1, weight=1)

        self.v_swagger = self._file_row(files, "Swagger / OpenAPI (input):", 0, kinds=yaml_kinds, invalidates=True)
        self.v_mapping = self._file_row(files, "SOR mapping spreadsheet:", 1, kinds=xlsx_kinds, invalidates=True)

        # optional multiple SOR API YAML files (validate mapped fields)
        ttk.Label(files, text="SOR API YAML file(s) — optional:").grid(row=2, column=0, sticky="nw", padx=6, pady=5)
        sorwrap = ttk.Frame(files)
        sorwrap.grid(row=2, column=1, columnspan=2, sticky="we", padx=6, pady=5)
        self.lb_sor = tk.Listbox(sorwrap, height=3, activestyle="none")
        self.lb_sor.pack(side="left", fill="x", expand=True)
        sb = ttk.Scrollbar(sorwrap, orient="vertical", command=self.lb_sor.yview)
        sb.pack(side="left", fill="y")
        self.lb_sor.config(yscrollcommand=sb.set)
        sbtns = ttk.Frame(sorwrap)
        sbtns.pack(side="left", padx=6)
        ttk.Button(sbtns, text="Add…", width=9, command=self._add_sor).pack(pady=(0, 3))
        ttk.Button(sbtns, text="Remove", width=9, command=self._remove_sor).pack()
        self._enable_list_drop(self.lb_sor)

        self.v_out = self._file_row(files, "Output swagger:", 3, save=True, kinds=yaml_kinds)
        self.v_report = self._file_row(files, "Markdown report (optional):", 4, save=True, kinds=md_kinds)
        self.v_html = self._file_row(files, "HTML change report (optional):", 5, save=True, kinds=html_kinds)

        opts = ttk.LabelFrame(self.root, text="Options")
        opts.pack(fill="x", padx=10, pady=6)
        self.v_keep_absent = tk.BooleanVar(value=False)
        self.v_disc = tk.BooleanVar(value=True)
        self.v_require_sor = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Keep attributes merely absent from sheet",
                        variable=self.v_keep_absent).grid(row=0, column=0, sticky="w", **pad)
        self.v_keep_absent.trace_add("write", lambda *a: self._invalidate())
        ttk.Checkbutton(opts, text="Add discriminator to base schemas",
                        variable=self.v_disc).grid(row=0, column=1, sticky="w", **pad)
        ttk.Checkbutton(opts, text="Require SOR field to exist in SOR YAML (else eliminate)",
                        variable=self.v_require_sor).grid(row=1, column=0, columnspan=2, sticky="w", **pad)
        self.v_require_sor.trace_add("write", lambda *a: self._invalidate())
        ttk.Label(opts, text="Discriminator property (set by Analyze):").grid(row=2, column=0, sticky="w", **pad)
        self.v_disc_prop = tk.StringVar(value="")
        ttk.Entry(opts, textvariable=self.v_disc_prop, width=24).grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(opts, text="Protected schemas (never pruned):").grid(row=3, column=0, sticky="w", **pad)
        self.v_protected = tk.StringVar(value="ErrorResponse")
        ttk.Entry(opts, textvariable=self.v_protected, width=36).grid(row=3, column=1, sticky="w", **pad)
        self.v_protected.trace_add("write", lambda *a: self._invalidate())

        adv = ttk.LabelFrame(self.root, text="Advanced — spreadsheet columns (1-based)")
        adv.pack(fill="x", padx=10, pady=6)
        self.v_lf = tk.IntVar(value=core.DEFAULT_SHEET_CFG["level_first_col"])
        self.v_ll = tk.IntVar(value=core.DEFAULT_SHEET_CFG["level_last_col"])
        self.v_dt = tk.IntVar(value=core.DEFAULT_SHEET_CFG["dtype_col"])
        self.v_sor = tk.IntVar(value=core.DEFAULT_SHEET_CFG["sor_col"])
        self.v_nu = tk.StringVar(value=core.DEFAULT_SHEET_CFG["not_used_text"])
        for i, (lbl, var) in enumerate([("Level first col", self.v_lf), ("Level last col", self.v_ll),
                                        ("Data Type col", self.v_dt), ("SOR Field col", self.v_sor)]):
            ttk.Label(adv, text=lbl + ":").grid(row=0, column=i * 2, sticky="e", padx=4, pady=4)
            ttk.Entry(adv, textvariable=var, width=5).grid(row=0, column=i * 2 + 1, sticky="w", padx=4, pady=4)
            var.trace_add("write", lambda *a: self._invalidate())
        ttk.Label(adv, text="'Not used' text:").grid(row=1, column=0, sticky="e", padx=4, pady=4)
        ttk.Entry(adv, textvariable=self.v_nu, width=24).grid(row=1, column=1, columnspan=3, sticky="w", padx=4, pady=4)
        self.v_nu.trace_add("write", lambda *a: self._invalidate())

        act = ttk.LabelFrame(self.root, text="STEP 2 → STEP 3 · Analyze, then Run", style="StepHdr.TLabelframe")
        act.pack(fill="x", padx=10, pady=(8, 4))
        row = ttk.Frame(act)
        row.pack(fill="x", padx=8, pady=8)
        self.analyze_btn = ttk.Button(row, text="STEP 2:  Analyze file", style="Step.TButton", command=self._on_analyze)
        self.analyze_btn.pack(side="left")
        ttk.Label(row, text="  ➜  ", style="Arrow.TLabel").pack(side="left")
        self.run_btn = ttk.Button(row, text="STEP 3:  Run transform  (approve)", style="Step.TButton",
                                  command=self._on_run, state="disabled")
        self.run_btn.pack(side="left")
        self.status = tk.StringVar(value="Start at STEP 1: choose the input swagger and the SOR mapping spreadsheet.")
        ttk.Label(act, textvariable=self.status, foreground="#5A6B78").pack(anchor="w", padx=10, pady=(0, 6))

        groups = ttk.LabelFrame(self.root, text="Review · proposed polymorphism groups   (filled by Analyze · edit to override)")
        groups.pack(fill="x", padx=10, pady=4)
        self.t_groups = tk.Text(groups, height=3, wrap="none")
        self.t_groups.pack(fill="x", padx=6, pady=6)

        dd = ttk.LabelFrame(self.root, text="Review · proposed inline de-duplication   (filled by Analyze · edit to override)")
        dd.pack(fill="x", padx=10, pady=4)
        self.t_dedupe = tk.Text(dd, height=2, wrap="none")
        self.t_dedupe.pack(fill="x", padx=6, pady=6)

        util = ttk.Frame(self.root)
        util.pack(fill="x", padx=10, pady=(2, 2))
        self.open_html_btn = ttk.Button(util, text="Open change report", command=self._open_html, state="disabled")
        self.open_html_btn.pack(side="left")
        self.open_dir_btn = ttk.Button(util, text="Open output folder", command=self._open_dir, state="disabled")
        self.open_dir_btn.pack(side="left", padx=6)
        ttk.Button(util, text="Clear log", command=lambda: self.log_box.delete("1.0", "end")).pack(side="left")

        logf = ttk.LabelFrame(self.root, text="Changes / log")
        logf.pack(fill="both", expand=True, padx=10, pady=(4, 10))
        self.log_box = scrolledtext.ScrolledText(logf, height=9, wrap="word", font=("Consolas", 10))
        self.log_box.pack(fill="both", expand=True, padx=6, pady=6)
        self.log_box.tag_config("del", foreground="#B3261E")
        self.log_box.tag_config("add", foreground="#1E7A34")
        self.log_box.tag_config("warn", foreground="#9A6A00")
        self.log_box.tag_config("hdr", foreground="#21295C", font=("Consolas", 11, "bold"))

    # ---- SOR YAML list ----------------------------------------------------- #
    def _enable_list_drop(self, widget):
        if not _HAS_DND or not hasattr(widget, "drop_target_register"):
            return
        try:
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", lambda e: self._add_sor_paths(_parse_drops(e.data)))
        except tk.TclError:
            pass

    def _add_sor(self):
        paths = filedialog.askopenfilenames(filetypes=[("YAML", "*.yaml *.yml"), ("All files", "*.*")])
        self._add_sor_paths(paths)

    def _add_sor_paths(self, paths):
        added = False
        for p in paths:
            p = p.strip()
            if p and p not in self.sor_swaggers:
                self.sor_swaggers.append(p)
                added = True
        if added:
            self._refresh_sor_list()
            self._invalidate()

    def _remove_sor(self):
        for i in reversed(self.lb_sor.curselection()):
            del self.sor_swaggers[i]
        self._refresh_sor_list()
        self._invalidate()

    def _refresh_sor_list(self):
        self.lb_sor.delete(0, "end")
        for p in self.sor_swaggers:
            self.lb_sor.insert("end", p)

    # ---- state ------------------------------------------------------------- #
    def _sig(self):
        return (self.v_swagger.get().strip(), self.v_mapping.get().strip(),
                tuple(self.sor_swaggers), self.v_require_sor.get(),
                self.v_keep_absent.get(), self.v_protected.get().strip(),
                self.v_lf.get(), self.v_ll.get(), self.v_dt.get(), self.v_sor.get(), self.v_nu.get())

    def _invalidate(self, *_):
        self.analysis = None
        self.analyzed_sig = None
        if hasattr(self, "run_btn"):
            self.run_btn.config(state="disabled")
            self.status.set("Inputs changed — click STEP 2 (Analyze) before running.")

    def _sheet_cfg(self):
        return {"level_first_col": self.v_lf.get(), "level_last_col": self.v_ll.get(),
                "dtype_col": self.v_dt.get(), "sor_col": self.v_sor.get(),
                "not_used_text": self.v_nu.get()}

    def _protected(self):
        return tuple(s.strip() for s in self.v_protected.get().split(",") if s.strip())

    # ---- logging ----------------------------------------------------------- #
    def _log(self, msg, tag=None):
        self.q.put((msg, tag))

    def _drain_log(self):
        try:
            while True:
                item = self.q.get_nowait()
                if isinstance(item, tuple) and len(item) == 2 and str(item[0]).startswith("__"):
                    self._handle_signal(item)
                    continue
                msg, tag = item if isinstance(item, tuple) else (item, None)
                self.log_box.insert("end", str(msg) + "\n", (tag,) if tag else ())
                self.log_box.see("end")
        except queue.Empty:
            pass
        self.root.after(100, self._drain_log)

    def _handle_signal(self, item):
        kind, payload = item
        if kind == "__ANALYZED__":
            self._apply_analysis(payload)
        elif kind == "__ANALYZE_ERR__":
            self.analyze_btn.config(state="normal")
            messagebox.showerror("Analyze failed", "See the log for details.")
        elif kind == "__DONE__":
            self.last_out, self.last_html = payload
            self.open_dir_btn.config(state="normal")
            if self.last_html:
                self.open_html_btn.config(state="normal")
            self.run_btn.config(state="normal")
            messagebox.showinfo("Complete", f"Wrote:\n{self.last_out}")
        elif kind == "__ERROR__":
            self.run_btn.config(state="normal")
            messagebox.showerror("Failed", "See the log for details.")

    # ---- open helpers ------------------------------------------------------ #
    def _open_html(self):
        if self.last_html and os.path.isfile(self.last_html):
            webbrowser.open("file://" + os.path.abspath(self.last_html))

    def _open_dir(self):
        if self.last_out:
            folder = os.path.dirname(os.path.abspath(self.last_out))
            try:
                os.startfile(folder)
            except AttributeError:
                webbrowser.open("file://" + folder)

    # ---- STEP 2 : analyze -------------------------------------------------- #
    def _on_analyze(self):
        swagger = self.v_swagger.get().strip()
        mapping = self.v_mapping.get().strip()
        if not swagger or not os.path.isfile(swagger):
            messagebox.showerror("Missing input", "Choose a valid input swagger (STEP 1).")
            return
        if not mapping or not os.path.isfile(mapping):
            messagebox.showerror("Missing input", "Choose a valid SOR mapping spreadsheet (STEP 1).")
            return
        for y in self.sor_swaggers:
            if not os.path.isfile(y):
                messagebox.showerror("File not found", f"SOR YAML does not exist:\n{y}")
                return
        sig = self._sig()
        self.analyze_btn.config(state="disabled")
        self.status.set("Analyzing…")
        self._log("=" * 64)
        extra = f" · {len(self.sor_swaggers)} SOR YAML(s)" if self.sor_swaggers else ""
        self._log(f"STEP 2 — analyzing {os.path.basename(swagger)}{extra}…")
        sor_swaggers = list(self.sor_swaggers)
        require = self.v_require_sor.get()
        keep_absent = self.v_keep_absent.get()
        protected = self._protected()
        sheet_cfg = self._sheet_cfg()

        def worker():
            try:
                res = core.analyze(swagger, mapping, sor_swaggers=sor_swaggers,
                                   require_sor_field=require, keep_absent=keep_absent,
                                   protected=protected, sheet_cfg=sheet_cfg)
                self.q.put(("__ANALYZED__", (sig, res)))
            except Exception:
                self._log("ERROR during analyze:\n" + traceback.format_exc(), "del")
                self.q.put(("__ANALYZE_ERR__", None))

        threading.Thread(target=worker, daemon=True).start()

    def _apply_analysis(self, payload):
        sig, res = payload
        self.analysis = res
        self.analyzed_sig = sig
        self.t_groups.delete("1.0", "end")
        self.t_groups.insert("1.0", "\n".join(res["group_specs"]))
        self.t_dedupe.delete("1.0", "end")
        self.t_dedupe.insert("1.0", "\n".join(res["dedupe_specs"]))
        self.v_disc_prop.set(res.get("discriminator", ""))
        self._log("Proposal for these files:", "hdr")
        self._log(f"   {len(res['eliminations'])} attribute(s) would be eliminated:", "hdr")
        for pathname, reason in res["eliminations"]:
            self._log(f"      − {pathname}   [{reason}]", "del")
        self._log(f"   {len(res['group_specs'])} polymorphism group(s) proposed:", "hdr")
        for s in res["group_specs"]:
            self._log(f"      + {s}", "add")
        self._log(f"   {len(res['dedupe_specs'])} inline de-dup(s) proposed:", "hdr")
        for s in res["dedupe_specs"]:
            self._log(f"      + {s}", "add")
        if res.get("discriminator"):
            self._log(f"   discriminator determined: {res['discriminator']}", "add")
        val = res.get("validation")
        if val is not None:
            self._log(f"   SOR YAML validation: {val['field_count']} SOR fields · "
                      f"{len(val['confirmed'])} confirmed · {len(val['missing'])} NOT found:", "hdr")
            for leaf, field in val["missing"]:
                self._log(f"      ! {leaf} → {field}  (not in SOR YAML)", "warn")
        self._log("Review the boxes above, then click STEP 3 (Run) to approve.")
        status = (f"Analyzed: {len(res['eliminations'])} elim · "
                  f"{len(res['group_specs'])} groups · {len(res['dedupe_specs'])} de-dup")
        if val is not None:
            status += f" · SOR check: {len(val['missing'])} not found"
        self.status.set(status + ". Review, then STEP 3 (Run).")
        self.analyze_btn.config(state="normal")
        self.run_btn.config(state="normal")

    # ---- STEP 3 : run ------------------------------------------------------ #
    def _collect_groups(self):
        return [core.parse_group_spec(l.strip())
                for l in self.t_groups.get("1.0", "end").splitlines() if l.strip()]

    def _collect_dedupe(self):
        return [core.parse_dedupe_spec(l.strip())
                for l in self.t_dedupe.get("1.0", "end").splitlines() if l.strip()]

    def _on_run(self):
        if self.analysis is None or self.analyzed_sig != self._sig():
            messagebox.showwarning("Analyze first",
                                   "The inputs changed since the last analysis.\n"
                                   "Click STEP 2 (Analyze), review, then STEP 3 (Run).")
            self._invalidate()
            return
        out = self.v_out.get().strip()
        if not out:
            messagebox.showerror("Missing output", "Choose an output swagger path (STEP 1).")
            return
        try:
            groups = self._collect_groups()
            dedupe = self._collect_dedupe()
        except Exception as ex:
            messagebox.showerror("Bad configuration", str(ex))
            return

        n_elim = len(self.analysis["eliminations"])
        val = self.analysis.get("validation")
        val_line = ""
        if val is not None:
            val_line = f"   • SOR YAML check: {len(val['missing'])} mapped field(s) not found in the SOR\n"
        if not messagebox.askokcancel(
                "STEP 3 · Approve transform",
                "The following changes will be written:\n\n"
                f"   • Eliminate {n_elim} attribute(s) with no SOR connection\n"
                f"   • Apply {len(groups)} polymorphism group(s)\n"
                f"   • De-duplicate {len(dedupe)} inline object(s)\n"
                f"{val_line}\n"
                f"Output:\n   {out}\n\nProceed?"):
            self._log("Run cancelled at approval.", "del")
            return

        html = self.v_html.get().strip() or (os.path.splitext(out)[0] + "_changes.html")
        self.v_html.set(html)
        report = self.v_report.get().strip() or None
        keep_absent = self.v_keep_absent.get()
        add_disc = self.v_disc.get()
        disc_prop = (self.v_disc_prop.get().strip()
                     or (self.analysis or {}).get("discriminator") or "context")
        protected = self._protected()
        sheet_cfg = self._sheet_cfg()
        swagger = self.v_swagger.get().strip()
        mapping = self.v_mapping.get().strip()
        sor_swaggers = list(self.sor_swaggers)
        require = self.v_require_sor.get()

        self.run_btn.config(state="disabled")
        self.open_html_btn.config(state="disabled")
        self.open_dir_btn.config(state="disabled")
        self._log("=" * 64)
        self._log("STEP 3 — approved. Running transform…")

        def worker():
            try:
                res = core.run(
                    swagger, mapping, out, report, html_report=html,
                    sor_swaggers=sor_swaggers, require_sor_field=require,
                    keep_absent=keep_absent, add_discriminator=add_disc,
                    discriminator_prop=disc_prop, poly_groups=groups, dedupe_pairs=dedupe,
                    auto_poly=False, auto_dedupe=False,
                    protected=protected, sheet_cfg=sheet_cfg, log=self._log)
                self._log("")
                self._log(f"CHANGES: {len(res['dropped'])} eliminated, "
                          f"{len(res['poly_log'])} polymorphism action(s), "
                          f"{len(res['dedupe_log'])} de-dup(s)", "hdr")
                for pathname, reason in res["dropped"]:
                    self._log(f"   − {pathname}   [{reason}]", "del")
                for line in res["poly_log"]:
                    self._log(f"   + {line}", "add")
                for line in res["dedupe_log"]:
                    self._log(f"   + de-dup: {line}", "add")
                self._log("\nDone. Open 'change report' for the colour-coded diff.")
                self.q.put(("__DONE__", (out, html)))
            except Exception:
                self._log("ERROR:\n" + traceback.format_exc(), "del")
                self.q.put(("__ERROR__", None))

        threading.Thread(target=worker, daemon=True).start()


def main():
    root = TkinterDnD.Tk() if _HAS_DND else tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
