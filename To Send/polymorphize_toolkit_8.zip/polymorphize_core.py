#!/usr/bin/env python3
"""
polymorphize_core.py
====================

Reusable engine that eliminates OpenAPI/Swagger attributes with no
System-of-Record (SOR) connection, using polymorphism (``allOf`` sub-typing,
optionally with a ``discriminator``). Shared by both the command-line wrapper
(``polymorphize_cli.py``) and the Windows GUI (``polymorphize_gui.py``).

Everything is parameterised - no schema names, column positions or family
groupings are hard-coded. Call :func:`run` with options, or use the pieces
directly.

Dependencies: ruamel.yaml, openpyxl
"""
import difflib
import html as _html
import os
import re

import openpyxl
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq

CONTAINER_TYPES = {"object", "array"}
DEFAULT_SHEET_CFG = {
    "level_first_col": 3,   # column C  (Level 1)
    "level_last_col": 7,    # column G  (Level 5)
    "dtype_col": 9,         # column I  (Data Type)
    "sor_col": 10,          # column J  (SOR Field)
    "not_used_text": "Not Used In SOR",
}


# --------------------------------------------------------------------------- #
# Spreadsheet -> SOR lookup
# --------------------------------------------------------------------------- #
def norm(name):
    """Normalise an attribute name for matching (case/space/punct insensitive)."""
    return re.sub(r"[^a-z0-9]", "", str(name).lower()) if name is not None else ""


def _index_one_workbook(xlsx_path, cfg):
    not_used = norm(cfg["not_used_text"])
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    index = {}
    for ws in wb.worksheets:
        for r in range(2, ws.max_row + 1):
            levels = [ws.cell(r, c).value
                      for c in range(cfg["level_first_col"], cfg["level_last_col"] + 1)]
            leaf = next((v for v in reversed(levels) if v not in (None, "")), None)
            if leaf is None or str(leaf).lower().startswith("level "):
                continue
            dtype = ws.cell(r, cfg["dtype_col"]).value
            sor = ws.cell(r, cfg["sor_col"]).value
            if str(dtype).strip().lower() in CONTAINER_TYPES:
                continue
            key = norm(leaf)
            if not key:
                continue
            is_mapped = sor not in (None, "") and norm(sor) != not_used
            prev = index.get(key)
            if prev is None:
                index[key] = {"status": "mapped" if is_mapped else "unmapped",
                              "sor": str(sor) if is_mapped else "", "leaf": str(leaf).strip()}
            elif is_mapped and prev["status"] != "mapped":
                index[key] = {"status": "mapped", "sor": str(sor), "leaf": str(leaf).strip()}
    return index


def build_sor_index(paths, sheet_cfg=None):
    """
    Build an SOR lookup from ONE OR MORE mapping spreadsheets.

    `paths` may be a single path or a list of paths. Results are merged across
    every workbook: a name is 'mapped' if ANY spreadsheet maps it to a concrete
    SOR field; otherwise 'unmapped'. This lets a swagger draw on several SOR
    mapping files at once. Container rows (Data Type object/array) are ignored so
    a class marked 'object' is never treated as an eliminable attribute.
    """
    cfg = dict(DEFAULT_SHEET_CFG, **(sheet_cfg or {}))
    if isinstance(paths, str):
        paths = [paths]
    merged = {}
    for p in paths:
        for key, entry in _index_one_workbook(p, cfg).items():
            prev = merged.get(key)
            if prev is None:
                merged[key] = entry
            elif entry["status"] == "mapped" and prev["status"] != "mapped":
                merged[key] = entry
    return merged


# --------------------------------------------------------------------------- #
# SOR YAML files -> the set of field names the System-of-Record exposes
# --------------------------------------------------------------------------- #
def collect_sor_fields(paths):
    """Parse one or more SOR OpenAPI/Swagger YAML files and return the set of
    normalised property names they expose (used to validate the mapping)."""
    if isinstance(paths, str):
        paths = [paths]
    yaml = YAML(typ="safe")
    fields = set()

    def walk(node):
        if isinstance(node, dict):
            props = node.get("properties")
            if isinstance(props, dict):
                for k in props:
                    fields.add(norm(k))
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    for p in paths:
        with open(p) as fh:
            walk(yaml.load(fh))
    fields.discard("")
    return fields


def _sor_tokens(field_value):
    """Split a mapping's SOR-field cell into candidate field tokens."""
    return [norm(t) for t in re.split(r"[,/;|]+|\s{2,}", str(field_value)) if norm(t)]


def _field_in_sor(field_value, sor_fields):
    toks = _sor_tokens(field_value)
    return any(t in sor_fields for t in toks) if toks else False


def validate_mapping(sor_index, sor_fields):
    """Cross-check every 'mapped' attribute's SOR field against the SOR YAML(s).
    Returns {'confirmed': [(leaf, field)], 'missing': [(leaf, field)],
             'field_count': int}."""
    confirmed, missing = [], []
    for _key, entry in sor_index.items():
        if entry.get("status") != "mapped":
            continue
        leaf = entry.get("leaf", "")
        field = entry.get("sor", "")
        if _field_in_sor(field, sor_fields):
            confirmed.append((leaf, field))
        else:
            missing.append((leaf, field))
    confirmed.sort()
    missing.sort()
    return {"confirmed": confirmed, "missing": missing, "field_count": len(sor_fields)}


# --------------------------------------------------------------------------- #
# Schema helpers
# --------------------------------------------------------------------------- #
def is_container(node):
    if not isinstance(node, dict):
        return False
    if "$ref" in node or "properties" in node or "items" in node:
        return True
    if "allOf" in node or "oneOf" in node or "anyOf" in node:
        return True
    return node.get("type") in CONTAINER_TYPES


def plain(node):
    if isinstance(node, dict):
        return {k: plain(v) for k, v in node.items()}
    if isinstance(node, list):
        return [plain(v) for v in node]
    return node


def drop_from_required(schema, name):
    req = schema.get("required")
    if isinstance(req, list) and name in req:
        req.remove(name)
        if not req:
            del schema["required"]


def _set_comment(node, text, indent=0):
    """Attach a start-comment to a CommentedMap, tolerant of ruamel quirks."""
    try:
        node.yaml_set_start_comment(text, indent=indent)
    except Exception:
        pass


# --------------------------------------------------------------------------- #
# Pruning
# --------------------------------------------------------------------------- #
def prune_schema(schema, sor, keep_absent, path, dropped,
                 sor_fields=None, require_sor_field=False):
    if not isinstance(schema, dict):
        return
    props = schema.get("properties")
    if isinstance(props, dict):
        for pname in list(props.keys()):
            pval = props[pname]
            if is_container(pval):
                prune_schema(pval, sor, keep_absent, f"{path}.{pname}", dropped,
                             sor_fields, require_sor_field)
                continue
            entry = sor.get(norm(pname))
            if entry is None:
                remove, reason = (not keep_absent), "absent-from-mapping"
            elif entry["status"] == "unmapped":
                remove, reason = True, "Not Used In SOR / blank"
            else:
                remove, reason = False, None
                if require_sor_field and sor_fields is not None and \
                        not _field_in_sor(entry.get("sor", ""), sor_fields):
                    remove, reason = True, f"SOR field '{entry.get('sor', '')}' not in SOR YAML"
            if remove:
                del props[pname]
                drop_from_required(schema, pname)
                dropped.append((f"{path}.{pname}", reason))
    if isinstance(schema.get("items"), dict):
        prune_schema(schema["items"], sor, keep_absent, f"{path}[]", dropped,
                     sor_fields, require_sor_field)
    for comb in ("allOf", "oneOf", "anyOf"):
        if isinstance(schema.get(comb), list):
            for i, sub in enumerate(schema[comb]):
                prune_schema(sub, sor, keep_absent, f"{path}.{comb}[{i}]", dropped,
                             sor_fields, require_sor_field)


# --------------------------------------------------------------------------- #
# Polymorphism refactor
# --------------------------------------------------------------------------- #
def refactor_polymorphism(schemas, members, base_name, disc_prop, add_disc, log):
    """Factor common properties of `members` into `base_name`; rewrite each member
    as allOf:[base, {extras}]. `members` is [(schema_name, disc_value), ...]."""
    present = [(n, v) for n, v in members
               if n in schemas and isinstance(schemas[n].get("properties"), dict)]
    if len(present) < 2:
        return False
    propmaps = {n: schemas[n]["properties"] for n, _ in present}
    common = set.intersection(*[set(p.keys()) for p in propmaps.values()])
    first = present[0][0]
    common = {k for k in common
              if all(plain(propmaps[n][k]) == plain(propmaps[first][k]) for n, _ in present)}
    if not common:
        return False

    base = CommentedMap()
    base["type"] = "object"
    base_props = CommentedMap()
    for k in propmaps[first]:
        if k in common:
            base_props[k] = propmaps[first][k]
    reqs = [set(schemas[n].get("required", []) or []) for n, _ in present]
    common_req = [k for k in base_props if all(k in r for r in reqs)]
    if add_disc:
        base_props[disc_prop] = CommentedMap([("type", "string")])
        common_req = [disc_prop] + common_req
    base["properties"] = base_props
    if common_req:
        base["required"] = common_req
    if add_disc:
        base["discriminator"] = CommentedMap([
            ("propertyName", disc_prop),
            ("mapping", CommentedMap([(v, f"#/components/schemas/{n}") for n, v in present])),
        ])
    schemas[base_name] = base
    _set_comment(base, f">>> CHANGE (added): base schema generated by SOR Polymorphizer - "
                       f"shared core of {', '.join(n for n, _ in present)}.", indent=4)

    for n, _v in present:
        extras = CommentedMap()
        for k in list(schemas[n]["properties"].keys()):
            if k not in common:
                extras[k] = schemas[n]["properties"][k]
        allof = CommentedSeq()
        allof.append(CommentedMap([("$ref", f"#/components/schemas/{base_name}")]))
        if extras:
            ext = CommentedMap()
            ext["type"] = "object"
            ext["properties"] = extras
            ext_req = [k for k in (schemas[n].get("required", []) or []) if k in extras]
            if ext_req:
                ext["required"] = ext_req
            allof.append(ext)
        new = CommentedMap()
        new["allOf"] = allof
        schemas[n] = new
        _set_comment(new, f">>> CHANGE (restructured): now allOf[{base_name}]"
                          + (f" + {list(extras.keys())}" if extras else "")
                          + " - attributes with no SOR connection omitted.", indent=4)
        log.append(f"{n} -> allOf[{base_name}" + (f", +{list(extras.keys())}]" if extras else "]"))
    log.insert(0, f"Base {base_name} holds common {sorted(common)}"
                  + (f" + discriminator '{disc_prop}'." if add_disc else "."))
    return True


def dedupe_inline(schemas, owner, prop, target, log):
    if owner not in schemas or target not in schemas:
        return
    op = schemas[owner].get("properties", {})
    node = op.get(prop)
    if not isinstance(node, dict) or "properties" not in node:
        return
    if set(node["properties"].keys()) == set(schemas[target].get("properties", {}).keys()):
        op[prop] = CommentedMap([("$ref", f"#/components/schemas/{target}")])
        log.append(f"{owner}.{prop} -> $ref {target} (identical shape)")


# --------------------------------------------------------------------------- #
# Auto-detection (optional convenience)
# --------------------------------------------------------------------------- #
def _body_schema_ref(holder):
    if not isinstance(holder, dict):
        return None
    content = holder.get("content")
    if not isinstance(content, dict):
        return None
    for _mt, mv in content.items():
        sch = mv.get("schema") if isinstance(mv, dict) else None
        if isinstance(sch, dict) and str(sch.get("$ref", "")).startswith("#/components/schemas/"):
            return sch["$ref"].split("/")[-1]
    return None


def operation_body_schemas(doc):
    """Return (request_schema_names, success_response_schema_names)."""
    requests, responses = [], []
    for _p, ops in (doc.get("paths") or {}).items():
        if not isinstance(ops, dict):
            continue
        for _m, op in ops.items():
            if not isinstance(op, dict):
                continue
            r = _body_schema_ref(op.get("requestBody", {}))
            if r and r not in requests:
                requests.append(r)
            for code, resp in (op.get("responses") or {}).items():
                if str(code).startswith("2"):
                    r = _body_schema_ref(resp)
                    if r and r not in responses:
                        responses.append(r)
    return requests, responses


def family_base_and_values(names):
    pre = os.path.commonprefix(names)
    suf = os.path.commonprefix([n[::-1] for n in names])[::-1]
    values = {}
    for n in names:
        mid = n[len(pre):len(n) - len(suf)] if (len(pre) + len(suf)) < len(n) else n
        values[n] = norm(mid) or norm(n)
    base = (pre + suf + "Base") if (pre or suf) else "PolymorphicBase"
    return base, values


def auto_detect_groups(doc, disc_prop):
    requests, responses = operation_body_schemas(doc)
    groups = []
    for family in (responses, requests):
        names = sorted(set(family))
        if len(names) >= 2:
            base, values = family_base_and_values(names)
            groups.append({"base": base, "disc_prop": disc_prop,
                           "members": [(n, values[n]) for n in names]})
    return groups


def auto_dedupe_all(schemas, log):
    """Replace any inline object identical (by property-key set) to a named schema."""
    keyset = {name: frozenset((sc.get("properties") or {}).keys())
              for name, sc in schemas.items() if isinstance(sc, dict) and "properties" in sc}
    for owner, sc in list(schemas.items()):
        props = sc.get("properties") if isinstance(sc, dict) else None
        if not isinstance(props, dict):
            continue
        for prop, node in list(props.items()):
            if isinstance(node, dict) and "properties" in node and "$ref" not in node:
                ks = frozenset(node["properties"].keys())
                for target, tks in keyset.items():
                    if target != owner and ks == tks and ks:
                        dedupe_inline(schemas, owner, prop, target, log)
                        break


def detect_dedupe_candidates(schemas):
    """Return [(owner, prop, target), ...] inline objects identical to a named schema.
    Non-mutating - used to PROPOSE de-duplication before it is applied."""
    keyset = {name: frozenset((sc.get("properties") or {}).keys())
              for name, sc in schemas.items() if isinstance(sc, dict) and "properties" in sc}
    out = []
    for owner, sc in schemas.items():
        props = sc.get("properties") if isinstance(sc, dict) else None
        if not isinstance(props, dict):
            continue
        for prop, node in props.items():
            if isinstance(node, dict) and "properties" in node and "$ref" not in node:
                ks = frozenset(node["properties"].keys())
                for target, tks in keyset.items():
                    if target != owner and ks == tks and ks:
                        out.append((owner, prop, target))
                        break
    return out


def _group_common(schemas, members):
    """Shared identical property keys across members, or None if a refactor
    would be a no-op (fewer than 2 members present, or no common core)."""
    present = [(n, v) for n, v in members
               if n in schemas and isinstance(schemas[n].get("properties"), dict)]
    if len(present) < 2:
        return None
    propmaps = {n: schemas[n]["properties"] for n, _ in present}
    common = set.intersection(*[set(p.keys()) for p in propmaps.values()])
    first = present[0][0]
    common = {k for k in common
              if all(plain(propmaps[n][k]) == plain(propmaps[first][k]) for n, _ in present)}
    return common or None


def group_to_spec(g):
    members = ", ".join(f"{n}:{v}" for n, v in g["members"])
    return f'{g["base"]} = {members}'


def propose_discriminator(groups):
    """Determine a discriminator property name from the detected group bases,
    e.g. bases 'ChequeResponseBase' + 'ChequeRequestBase' -> 'chequeContext'.
    Returns '' when there are no groups (nothing to discriminate)."""
    if not groups:
        return ""
    # strip role words so 'ChequeResponseBase'/'ChequeRequestBase' -> 'Cheque'
    cleaned = [re.sub(r"(Request|Response|Base)", "", g["base"]) for g in groups]
    pre = re.sub(r"[^A-Za-z0-9]+$", "", os.path.commonprefix([c for c in cleaned if c]))
    if not pre:  # fallback: only strip the trailing 'Base'
        alt = [re.sub(r"Base$", "", g["base"]) for g in groups]
        pre = re.sub(r"[^A-Za-z0-9]+$", "", os.path.commonprefix(alt))
    if not pre:
        return "context"
    return pre[0].lower() + pre[1:] + "Context"


def dedupe_to_spec(t):
    owner, prop, target = t
    return f"{owner}.{prop} = {target}"


def analyze(swagger, mapping, *, sor_swaggers=None, require_sor_field=False,
            keep_absent=False, protected=("ErrorResponse",),
            sheet_cfg=None, discriminator_prop="resultContext"):
    """Inspect a swagger + mapping and PROPOSE the transform without writing anything.

    Returns a dict:
      eliminations : [(path, reason), ...]   attributes that would be removed
      groups       : [group dict, ...]        applicable polymorphism families
      dedupe       : [(owner, prop, target)]  inline de-dup candidates
      group_specs  : ['Base = A:v, B:v', ...] editable text form of groups
      dedupe_specs : ['Owner.prop = Target']  editable text form of de-dups
    Detection runs on the pruned+deduped shape so it matches what run() will do.
    """
    sor = build_sor_index(mapping, sheet_cfg)
    sor_swaggers = list(sor_swaggers or [])
    sor_fields = collect_sor_fields(sor_swaggers) if sor_swaggers else None
    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.width = 4096
    with open(swagger) as fh:
        doc = yaml.load(fh)
    schemas = (doc.get("components") or {}).get("schemas") or {}

    dropped = []
    for name in list(schemas.keys()):
        if name in (protected or ()):
            continue
        prune_schema(schemas[name], sor, keep_absent, name, dropped,
                     sor_fields, require_sor_field)

    dedupe = detect_dedupe_candidates(schemas)
    dlog = []
    for owner, prop, target in dedupe:
        dedupe_inline(schemas, owner, prop, target, dlog)

    groups = [g for g in auto_detect_groups(doc, discriminator_prop)
              if _group_common(schemas, g["members"])]

    return {
        "eliminations": dropped,
        "groups": groups,
        "dedupe": dedupe,
        "group_specs": [group_to_spec(g) for g in groups],
        "dedupe_specs": [dedupe_to_spec(t) for t in dedupe],
        "discriminator": propose_discriminator(groups),
        "validation": validate_mapping(sor, sor_fields) if sor_fields is not None else None,
    }


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #
def annotate_document(doc, dropped, poly_log, dedupe_log, n_bases):
    """Make the changes visible *inside* the output swagger itself:
    a top banner comment, an info.x-sor-polymorphizer change record, and
    per-schema comments on directly-pruned named schemas."""
    banner = (
        "############################################################\n"
        "#  Transformed by SOR Polymorphizer\n"
        f"#   - {len(dropped)} attribute(s) with no SOR connection eliminated\n"
        f"#   - {n_bases} schema group(s) refactored with polymorphism\n"
        f"#   - {len(dedupe_log)} inline object(s) de-duplicated\n"
        "#  Full change list: see info.x-sor-polymorphizer below,\n"
        "#  or the colour-coded HTML diff report.\n"
        "#  Change sites are marked in-file with '>>> CHANGE' comments.\n"
        "############################################################"
    )
    _set_comment(doc, banner, indent=0)

    info = doc.get("info")
    if isinstance(info, dict):
        rec = CommentedMap()
        rec["summary"] = (f"{len(dropped)} non-SOR attributes eliminated; "
                          f"{n_bases} groups polymorphized; "
                          f"{len(dedupe_log)} inline objects de-duplicated.")
        rec["eliminatedAttributes"] = CommentedSeq([f"{p}  ({r})" for p, r in dropped])
        rec["polymorphism"] = CommentedSeq(list(poly_log))
        rec["deduplication"] = CommentedSeq(list(dedupe_log))
        info["x-sor-polymorphizer"] = rec

    # per-schema comment listing directly removed leaves (best effort)
    schemas = doc.get("components", {}).get("schemas", {})
    by_schema = {}
    for path, reason in dropped:
        top = path.split(".")[0].split("[")[0]
        by_schema.setdefault(top, []).append(path.split(".", 1)[-1])
    for name, attrs in by_schema.items():
        node = schemas.get(name)
        if isinstance(node, dict) and "allOf" not in node:
            _set_comment(node, ">>> CHANGE (removed, no SOR): " + ", ".join(attrs), indent=4)


def write_html_report(original_path, output_path, dropped, poly_log, dedupe_log, html_path,
                      validation=None):
    """Write a self-contained, colour-coded HTML diff of original vs output."""
    with open(original_path, encoding="utf-8") as fh:
        orig = fh.read().splitlines()
    with open(output_path, encoding="utf-8") as fh:
        new = fh.read().splitlines()

    rows = []
    for line in difflib.unified_diff(orig, new, fromfile="original", tofile="polymorphized",
                                     lineterm="", n=3):
        esc = _html.escape(line)
        if line.startswith("+++") or line.startswith("---"):
            cls = "meta"
        elif line.startswith("@@"):
            cls = "hunk"
        elif line.startswith("+"):
            cls = "add"
        elif line.startswith("-"):
            cls = "del"
        else:
            cls = "ctx"
        rows.append(f'<div class="line {cls}">{esc or "&nbsp;"}</div>')

    def li(items):
        return "".join(f"<li>{_html.escape(str(x))}</li>" for x in items) or "<li><em>none</em></li>"

    elim = "".join(
        f'<tr><td class="mono">{_html.escape(p)}</td><td>{_html.escape(r)}</td></tr>'
        for p, r in dropped) or '<tr><td colspan="2"><em>none</em></td></tr>'

    val_card = ""
    val_section = ""
    if validation is not None:
        val_card = (f'<div class="card"><div class="n">{len(validation["missing"])}</div>'
                    f'<div class="l">SOR fields<br>not found in SOR YAML</div></div>')
        if validation["missing"]:
            rows_v = "".join(
                f'<tr><td class="mono">{_html.escape(leaf)}</td>'
                f'<td class="mono" style="color:#B3261E">{_html.escape(field)}</td></tr>'
                for leaf, field in validation["missing"])
            body_v = (f'<table><tr><th>Mapped attribute</th><th>SOR field (not in SOR YAML)</th></tr>{rows_v}</table>')
        else:
            body_v = "<p><em>Every mapped attribute's SOR field was found in the SOR YAML(s).</em></p>"
        val_section = (f'<h2>SOR YAML validation  '
                       f'<span style="font-weight:400;color:#5A6B78">'
                       f'({validation["field_count"]} SOR fields discovered · '
                       f'{len(validation["confirmed"])} confirmed · {len(validation["missing"])} not found)</span></h2>'
                       f'{body_v}')

    return _write(html_path, f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>SOR Polymorphizer - change report</title>
<style>
 body{{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f8;color:#1f2a33}}
 header{{background:#21295C;color:#fff;padding:20px 28px}}
 header h1{{margin:0;font-size:20px}} header p{{margin:6px 0 0;color:#CADCFC}}
 .wrap{{padding:22px 28px;max-width:1200px;margin:0 auto}}
 .cards{{display:flex;gap:14px;margin-bottom:20px;flex-wrap:wrap}}
 .card{{background:#fff;border-radius:10px;padding:16px 20px;box-shadow:0 1px 4px rgba(0,0,0,.1);min-width:150px}}
 .card .n{{font-size:30px;font-weight:700;color:#065A82}} .card .l{{font-size:13px;color:#5A6B78}}
 h2{{font-size:15px;color:#21295C;margin:20px 0 8px}}
 table{{border-collapse:collapse;width:100%;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
 td,th{{padding:7px 12px;border-bottom:1px solid #eef2f5;text-align:left;font-size:13px}}
 .mono{{font-family:Consolas,monospace;color:#B33A3A}}
 ul{{background:#fff;border-radius:8px;padding:12px 12px 12px 32px;box-shadow:0 1px 4px rgba(0,0,0,.08);font-size:13px}}
 .diff{{background:#0d1b2a;border-radius:8px;padding:14px;overflow:auto;font-family:Consolas,monospace;font-size:12.5px;line-height:1.5}}
 .line{{white-space:pre;padding:0 6px;border-radius:2px}}
 .add{{background:#123d1e;color:#8ff0a4}} .del{{background:#4a1420;color:#ff9db0}}
 .hunk{{color:#6ea8fe;margin-top:6px}} .meta{{color:#8b949e}} .ctx{{color:#c9d1d9}}
 .legend span{{display:inline-block;padding:2px 10px;border-radius:4px;margin-right:8px;font-size:12px}}
</style></head><body>
<header><h1>SOR Polymorphizer — change report</h1>
<p>{_html.escape(os.path.basename(original_path))} → {_html.escape(os.path.basename(output_path))}</p></header>
<div class="wrap">
 <div class="cards">
   <div class="card"><div class="n">{len(dropped)}</div><div class="l">attributes eliminated<br>(no SOR connection)</div></div>
   <div class="card"><div class="n">{len(poly_log)}</div><div class="l">polymorphism actions</div></div>
   <div class="card"><div class="n">{len(dedupe_log)}</div><div class="l">inline objects de-duplicated</div></div>
   {val_card}
 </div>
 <h2>Attributes eliminated</h2>
 <table><tr><th>Attribute</th><th>Reason</th></tr>{elim}</table>
 {val_section}
 <h2>Polymorphism applied</h2><ul>{li(poly_log)}</ul>
 <h2>De-duplication</h2><ul>{li(dedupe_log)}</ul>
 <h2>Full diff <span class="legend"><span class="add">added</span><span class="del">removed</span></span></h2>
 <div class="diff">{''.join(rows)}</div>
</div></body></html>
""")


def _write(path, text):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path


def build_report(swagger, mapping, out, dropped, poly_log, dedupe_log, validation=None):
    lines = ["# SOR-driven polymorphism refactor\n",
             f"* Source swagger: `{swagger}`",
             f"* SOR mapping:   `{mapping}`",
             f"* Output:        `{out}`\n",
             f"## Attributes eliminated ({len(dropped)})\n"]
    if dropped:
        for pathname, reason in dropped:
            lines.append(f"* `{pathname}`  — {reason}")
    else:
        lines.append("* (none)")
    lines.append("\n## Polymorphism applied\n")
    lines += (poly_log or ["* (no shared-schema differences required a base/profile split)"])
    if dedupe_log:
        lines.append("\n## De-duplication\n")
        lines += [f"* {d}" for d in dedupe_log]
    if validation is not None:
        lines.append(f"\n## SOR YAML validation "
                     f"({len(validation['confirmed'])} confirmed, {len(validation['missing'])} not found)\n")
        lines.append(f"* {validation['field_count']} SOR field name(s) discovered in the SOR YAML file(s).")
        if validation["missing"]:
            lines.append("* Mapped attributes whose SOR field was NOT found in the SOR YAML(s):")
            for leaf, field in validation["missing"]:
                lines.append(f"    * `{leaf}` → `{field}`")
        else:
            lines.append("* Every mapped attribute's SOR field was found in the SOR YAML(s).")
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------- #
# Orchestrator
# --------------------------------------------------------------------------- #
def run(swagger, mapping, out, report=None, *, html_report=None, sor_swaggers=None,
        require_sor_field=False, keep_absent=False,
        add_discriminator=False, discriminator_prop="resultContext", poly_groups=None,
        dedupe_pairs=None, auto_poly=False, auto_dedupe=False, protected=("ErrorResponse",),
        sheet_cfg=None, log=lambda m: None):
    """Transform `swagger` into `out`. Returns a results dict."""
    mapping_display = os.path.basename(mapping) if isinstance(mapping, str) else str(mapping)
    log(f"Reading SOR mapping: {mapping_display}")
    sor = build_sor_index(mapping, sheet_cfg)
    log(f"  {len(sor)} attribute mappings loaded.")

    sor_swaggers = list(sor_swaggers or [])
    sor_fields = None
    validation = None
    if sor_swaggers:
        sor_fields = collect_sor_fields(sor_swaggers)
        log(f"  {len(sor_fields)} SOR field name(s) loaded from {len(sor_swaggers)} SOR YAML file(s).")

    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.width = 4096
    with open(swagger) as fh:
        doc = yaml.load(fh)
    schemas = doc["components"]["schemas"]

    if sor_fields is not None:
        validation = validate_mapping(sor, sor_fields)
        if validation["missing"]:
            log(f"  SOR YAML check: {len(validation['missing'])} mapped field(s) not found in the SOR YAML(s).")

    dropped = []
    for name in list(schemas.keys()):
        if name in (protected or ()):
            continue
        prune_schema(schemas[name], sor, keep_absent, name, dropped,
                     sor_fields, require_sor_field)
    log(f"Pruned {len(dropped)} attribute(s) with no SOR connection.")

    dedupe_log = []
    for owner, prop, target in (dedupe_pairs or []):
        dedupe_inline(schemas, owner, prop, target, dedupe_log)
    if auto_dedupe:
        auto_dedupe_all(schemas, dedupe_log)

    poly_log = []
    n_bases = 0
    groups = list(poly_groups or [])
    if auto_poly and not groups:
        groups = auto_detect_groups(doc, discriminator_prop)
    for g in groups:
        sub = []
        ok = refactor_polymorphism(schemas, g["members"], g["base"],
                                   g.get("disc_prop", discriminator_prop),
                                   add_discriminator, sub)
        if ok:
            poly_log += sub
            n_bases += 1
        else:
            log(f"  Group '{g['base']}' skipped (no shared identical core).")

    # make every change visible inside the output file itself
    annotate_document(doc, dropped, poly_log, dedupe_log, n_bases)

    with open(out, "w") as fh:
        yaml.dump(doc, fh)
    log(f"Wrote {out}")

    report_txt = build_report(swagger, mapping_display, out, dropped, poly_log, dedupe_log, validation)
    if report:
        with open(report, "w") as fh:
            fh.write(report_txt)
        log(f"Wrote {report}")

    html_path = None
    if html_report:
        html_path = write_html_report(swagger, out, dropped, poly_log, dedupe_log, html_report, validation)
        log(f"Wrote {html_report}")

    return {"dropped": dropped, "poly_log": poly_log, "dedupe_log": dedupe_log,
            "report": report_txt, "out": out, "html": html_path, "n_bases": n_bases,
            "validation": validation}


# --------------------------------------------------------------------------- #
# Parsers shared by CLI + GUI
# --------------------------------------------------------------------------- #
def parse_group_spec(text):
    """'Base = SchemaA:valA, SchemaB:valB'  ->  {'base','disc_prop'(None),'members'}."""
    if "=" not in text:
        raise ValueError(f"group must be 'Base = SchemaA:val, SchemaB:val' (got: {text!r})")
    base, rest = text.split("=", 1)
    members = []
    for part in rest.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            schema, val = part.split(":", 1)
            members.append((schema.strip(), val.strip()))
        else:
            members.append((part, norm(part)))
    return {"base": base.strip(), "members": members}


def parse_dedupe_spec(text):
    """'Owner.prop = TargetSchema' -> (owner, prop, target)."""
    if "=" not in text or "." not in text.split("=", 1)[0]:
        raise ValueError(f"dedupe must be 'Owner.prop = Target' (got: {text!r})")
    left, target = text.split("=", 1)
    owner, prop = left.strip().split(".", 1)
    return (owner.strip(), prop.strip(), target.strip())
